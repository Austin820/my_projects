-- MySQL dump 10.13  Distrib 8.0.39, for Win64 (x86_64)
--
-- Host: localhost    Database: survey_madness
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `options`
--

DROP TABLE IF EXISTS `options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `options` (
  `id` int NOT NULL AUTO_INCREMENT,
  `poll_id` int NOT NULL,
  `text` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `poll_id` (`poll_id`),
  CONSTRAINT `options_ibfk_1` FOREIGN KEY (`poll_id`) REFERENCES `polls` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `options`
--

LOCK TABLES `options` WRITE;
/*!40000 ALTER TABLE `options` DISABLE KEYS */;
INSERT INTO `options` VALUES (1,7,'Cats'),(2,7,'Dogs'),(3,8,'Chicken '),(4,8,'Egg'),(5,9,'Yes'),(6,9,'No'),(7,9,'Varies'),(8,10,'Yes'),(9,10,'No'),(10,11,'Inherent meaning'),(11,11,'created meaning'),(12,12,'Society imposes guilt'),(13,12,'The soul creates guilt'),(14,13,'Yes, morality collapses'),(15,13,' No, morality exists beyond God'),(16,14,'Logic and reasoning'),(17,14,'Gut feeling or intuition'),(18,14,'Advice from others'),(19,14,'Past experiences'),(20,15,'More time'),(21,15,'More money'),(22,16,'Yes'),(23,16,'Hell yes'),(24,17,'Up to 4 times'),(25,17,'Three'),(26,17,'Twice'),(27,17,'Once 😢'),(28,17,'Eat?'),(29,18,'Instagram'),(30,18,'Youtube'),(31,18,'Tiktok'),(32,18,'Twitter/X'),(33,19,'Yes'),(34,19,'Yes'),(35,20,'Shawshank Redemption'),(36,20,'Braveheart'),(37,20,'American Beauty'),(38,20,'Forrest Gump'),(39,21,'China'),(40,21,'USA'),(41,21,'Russia'),(42,21,'India');
/*!40000 ALTER TABLE `options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `polls`
--

DROP TABLE IF EXISTS `polls`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `polls` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `created_by` int NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `description` text,
  `user_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `created_by` (`created_by`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `polls_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  CONSTRAINT `polls_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `polls`
--

LOCK TABLES `polls` WRITE;
/*!40000 ALTER TABLE `polls` DISABLE KEYS */;
INSERT INTO `polls` VALUES (7,'Cats or Dogs?',1,'2025-03-13 19:59:12','Man\'s best pal',1),(8,'Chicken or the Egg',1,'2025-03-13 20:06:40','What came first? ',1),(9,'Is crypto a scam?',2,'2025-03-13 21:31:12','Is cryptocurrency a way for the haves to take from the have nots',2),(10,'Free will or determinism',1,'2025-03-13 21:36:09','is everything predetermined',1),(11,'Does life have inherent meaning or do we create our own meaning?',1,'2025-03-13 21:39:55','Existential meaning',1),(12,'Does guilt come from society or from within the soul?',1,'2025-03-13 21:44:32','',1),(13,'If there is no God, is everything truly permitted?',2,'2025-03-13 21:59:52','',2),(14,'Which factor influences your decision-making the most?',3,'2025-03-14 00:05:05','Everyone approaches decisions differently—some rely on logic, while others trust their emotions or external guidance. What plays the biggest role in your choices?',3),(15,'Would you rather have more time or more money?',4,'2025-03-14 07:01:27','Time and money are both valuable, but if you had to choose, which would you want more of?',4),(16,'Ruto must GO!!!',5,'2025-03-16 10:03:26','',5),(17,'How many times do you eat a day as a comrade?',6,'2025-03-16 12:46:26','',6),(18,'If you had to scrap all social media except one, which would you keep?',6,'2025-03-16 12:56:37','',6),(19,'Is the GDP of Kenya greater than that of Uganda?',11,'2025-03-20 15:48:45','',11),(20,'Which of these is the better movie',9,'2025-03-25 16:57:38','',9),(21,'Which of these countries is likely to be a global superpower in 50 years',10,'2025-03-25 17:00:23','',10);
/*!40000 ALTER TABLE `polls` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'JohnDoe','JohnDoe2000','2025-03-13 18:59:27'),(2,'JaneDoe','jANEdOE2000','2025-03-13 21:28:37'),(3,'MichaelPrince','mpzoom','2025-03-14 00:00:16'),(4,'Ninjabean','ningabean','2025-03-14 07:00:25'),(5,'fachRuto','fachRuto','2025-03-16 09:59:58'),(6,'Manmade','manmade','2025-03-16 12:41:15'),(7,'uggzchoppa','ugchoppa','2025-03-17 11:28:45'),(8,'kevinjames','kevinjames','2025-03-20 15:34:08'),(9,'justinkilavi','justinkilavi','2025-03-20 15:39:55'),(10,'olivermutati','oliver','2025-03-20 15:43:16'),(11,'olivermutuma','123456','2025-03-20 15:45:13'),(12,'celestialdummy','celedumb','2025-03-26 13:40:07');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `votes`
--

DROP TABLE IF EXISTS `votes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `votes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `poll_id` int NOT NULL,
  `option_id` int NOT NULL,
  `user_id` int NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_vote` (`poll_id`,`user_id`),
  KEY `option_id` (`option_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `votes_ibfk_1` FOREIGN KEY (`poll_id`) REFERENCES `polls` (`id`) ON DELETE CASCADE,
  CONSTRAINT `votes_ibfk_2` FOREIGN KEY (`option_id`) REFERENCES `options` (`id`) ON DELETE CASCADE,
  CONSTRAINT `votes_ibfk_3` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=87 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `votes`
--

LOCK TABLES `votes` WRITE;
/*!40000 ALTER TABLE `votes` DISABLE KEYS */;
INSERT INTO `votes` VALUES (4,8,3,1,'2025-03-13 21:27:04'),(5,7,2,1,'2025-03-13 21:27:16'),(6,8,4,2,'2025-03-13 21:28:58'),(7,7,1,2,'2025-03-13 21:29:08'),(8,9,7,2,'2025-03-13 21:31:22'),(9,9,5,1,'2025-03-13 21:31:51'),(10,10,9,1,'2025-03-13 21:36:25'),(11,11,10,1,'2025-03-13 21:40:14'),(12,12,12,1,'2025-03-13 21:45:01'),(13,12,13,2,'2025-03-13 21:50:03'),(14,11,11,2,'2025-03-13 21:54:00'),(15,10,8,2,'2025-03-13 21:58:47'),(16,13,14,2,'2025-03-13 22:00:09'),(17,13,15,1,'2025-03-13 22:01:06'),(18,13,15,3,'2025-03-14 00:00:56'),(19,12,12,3,'2025-03-14 00:01:10'),(20,11,11,3,'2025-03-14 00:01:18'),(21,10,9,3,'2025-03-14 00:01:31'),(22,9,7,3,'2025-03-14 00:01:39'),(23,8,3,3,'2025-03-14 00:01:47'),(24,7,2,3,'2025-03-14 00:01:56'),(25,14,16,3,'2025-03-14 00:05:23'),(26,14,17,2,'2025-03-14 00:08:10'),(27,14,19,1,'2025-03-14 00:08:30'),(28,15,21,4,'2025-03-14 07:01:46'),(29,13,15,4,'2025-03-14 07:02:00'),(30,7,2,4,'2025-03-14 07:22:30'),(31,14,17,4,'2025-03-14 07:23:01'),(32,12,12,4,'2025-03-14 17:29:08'),(33,11,11,4,'2025-03-14 17:29:17'),(34,10,8,4,'2025-03-14 17:29:28'),(35,9,5,4,'2025-03-14 17:29:39'),(36,8,4,4,'2025-03-14 17:29:47'),(37,15,20,2,'2025-03-14 17:30:14'),(38,15,21,1,'2025-03-14 17:30:31'),(39,15,21,3,'2025-03-14 17:30:43'),(40,16,23,5,'2025-03-16 10:03:39'),(41,16,23,2,'2025-03-16 12:16:19'),(42,16,23,1,'2025-03-16 12:17:35'),(43,16,23,3,'2025-03-16 12:17:50'),(44,16,23,4,'2025-03-16 12:18:10'),(45,16,23,6,'2025-03-16 12:41:36'),(46,17,28,6,'2025-03-16 12:46:39'),(47,18,32,6,'2025-03-16 12:56:46'),(48,15,21,6,'2025-03-16 12:57:41'),(49,14,16,6,'2025-03-16 12:57:55'),(50,13,15,6,'2025-03-16 12:58:02'),(51,12,12,6,'2025-03-16 12:58:10'),(52,11,10,6,'2025-03-16 12:58:22'),(53,10,8,6,'2025-03-16 12:58:37'),(54,9,7,6,'2025-03-16 12:58:43'),(55,8,4,6,'2025-03-16 12:58:52'),(56,7,1,6,'2025-03-16 12:58:59'),(57,16,23,7,'2025-03-17 11:29:09'),(58,17,28,7,'2025-03-17 11:29:24'),(59,18,31,2,'2025-03-18 20:16:52'),(60,17,27,3,'2025-03-18 20:17:15'),(61,17,24,2,'2025-03-20 15:19:45'),(62,17,26,1,'2025-03-20 15:20:00'),(63,17,27,4,'2025-03-20 15:20:34'),(64,17,28,5,'2025-03-20 15:21:01'),(65,17,27,8,'2025-03-20 15:34:39'),(66,15,21,8,'2025-03-20 15:36:17'),(67,17,25,9,'2025-03-20 15:40:15'),(68,17,28,11,'2025-03-20 15:45:33'),(69,7,2,11,'2025-03-20 15:45:42'),(70,15,21,11,'2025-03-20 15:48:06'),(71,14,18,11,'2025-03-20 15:48:19'),(72,19,33,11,'2025-03-20 15:48:56'),(73,16,22,9,'2025-03-25 16:54:12'),(74,20,37,9,'2025-03-25 16:57:47'),(75,19,34,10,'2025-03-25 16:58:39'),(76,20,35,10,'2025-03-25 16:59:07'),(77,21,39,10,'2025-03-25 17:00:34'),(78,21,40,8,'2025-03-25 17:01:00'),(79,20,36,8,'2025-03-25 17:01:09'),(80,8,4,11,'2025-03-25 17:01:31'),(81,21,40,11,'2025-03-25 17:01:49'),(82,20,38,11,'2025-03-25 17:02:01'),(83,21,42,1,'2025-03-26 13:19:23'),(84,17,27,12,'2025-03-26 13:40:37'),(85,8,4,12,'2025-03-26 13:53:47'),(86,20,37,12,'2025-03-26 13:54:13');
/*!40000 ALTER TABLE `votes` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-03-26 21:13:52
